export const API_ENDPOINTS = {
    placeholder : '/todos',
}