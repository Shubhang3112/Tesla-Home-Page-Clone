import './App.css';
import HomePage from './pages/Home_Page';

function App() {
  return (
    <HomePage />
  );
}

export default App;
